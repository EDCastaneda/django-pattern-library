from django.apps import AppConfig


class PatternLibraryAppConfig(AppConfig):
    name = 'pattern_library'
